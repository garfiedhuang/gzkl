﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.


$(document).ready(function () {

    var a = '9c1eee6eef2f15304073c1159a7c2ed59916bf5a66dc66271a93191a36ba6b32909d5b303d63b92366a36ccc47941c07d9a536015644e8f874e36d42fa37a1fe';
    var b = 'ddf1ae4d992276f9f63402b12c46e260b700d2b6126be9ce53c10c48a7dffab38a79a64f4735b0941dcd804d9a46b7de090cd9bf662b264409aac8c913ab5f6e';


    var aaa = keccak512('0400Y40CB225019(3000KN)');

    //alert(aaa);

    //if (a === aaa) {
    //    alert(true);
    //}

    var aaaa = '0401广西交通研究院\r\n';
    var bbb = keccak512(aaaa);

    alert(bbb);


    //var aaa = CryptoJS.SHA3('0401广西交通研究院\r\n', 512);
    //alert(aaa);

    //var a = CryptoJS.SHA3('0400', 512);
    //alert(a);

    //var aaa = CryptoJS.SHA3('0401广西交通研究院\r', 512);
    //alert(aaa);

    //var aaa = CryptoJS.SHA3('0401广西交通研究院\n', 512);
    //alert(aaa);

    //var aaa = CryptoJS.SHA3('0401广西交通研究院\n\r', 512);
    //alert(aaa);

    //var bbb = CryptoJS.SHA3('0400Y40CB225019(3000KN)', 512);
    //alert(bbb);


    //var ccc = CryptoJS.SHA3('2840401', 512);
    //alert(ccc);

    //var ddd = CryptoJS.SHA3('2840401广西交通研究院', 512);
    //alert(ddd);


    //var eee = CryptoJS.SHA3('284广西交通研究院', 512);
    //alert(eee);
});