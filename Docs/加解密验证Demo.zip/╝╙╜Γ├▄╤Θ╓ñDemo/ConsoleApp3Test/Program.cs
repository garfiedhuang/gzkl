﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using GZKL.Client.UI.Common;
using JavaScriptEngineSwitcher.ChakraCore;
using JavaScriptEngineSwitcher.Core;
using JavaScriptEngineSwitcher.Jint;
using JavaScriptEngineSwitcher.V8;
using Jint;
using Jint.Native;

namespace ConsoleApp3Test
{
    internal class Program
    {

        static string ConvertToUnicodeStr(string s, bool convert2 = true, bool convert4 = true)
        {
            var array = s.ToCharArray();
            StringBuilder sb = new StringBuilder();
            int i = 0;
            while (i < array.Length)
            {
                if (i == array.Length - 1)
                {
                    if (convert2)
                        sb.AppendFormat("\\u{0:X4}", System.Convert.ToInt32(array[i]));
                    else
                        sb.Append(array[i].ToString());
                    break;
                }

                var c0 = array[i];
                var c1 = array[i + 1];
                if (char.IsSurrogatePair(c0, c1))
                {
                    sb.AppendFormat("\\U{0:X8}", char.ConvertToUtf32(c0, c1));
                    i += 2;
                }
                else
                {
                    if (convert2)
                        sb.AppendFormat("\\u{0:X4}", System.Convert.ToInt32(array[i]));
                    else
                        sb.Append(array[i].ToString());
                    i += 1;
                }
            }

            return sb.ToString();
        }


        static void Main(string[] args)
        {

            #region 

            var templateFile = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "aaa.mdb");

            //templateFile = @"D:\Work\Demo\ConsoleApp3Test\ConsoleApp3Test\aaa.mdb";

            //SecurityHelper.UncrptAccessDb(templateFile);


            //#region DB

            var dsnName = $"AutoAcsTest_DB";
            var pwd = "AutoAcs";
            var database = templateFile;
            var path = $"DSN={dsnName}";

            if (string.IsNullOrEmpty(database) || !System.IO.File.Exists(database))
            {
                throw new Exception($"数据库文件不存在，请检查！{database}");
            }

            DsnHelper.CreateDSN(dsnName, pwd, database);//创建DSN

           var dt = OdbcHelper.DataTable("select * from Base_COMPA", path);

            var aaas = "0401广西交通研究院\r\n";
            var bbbb = "广西交通研究院\r\n";

            var dr = dt.Rows[1];
            var name = dr["UnitName"];


            var jsPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "sha3.min.js");

            jsPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "sha3.js");
            jsPath = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "sha.js");

            var scripts = File.ReadAllText(jsPath);

            try
            {
                //var encrypt = new Engine().Execute(jsPath).GetValue("keccak512");
                //var encrypt = new Engine().Execute(jsPath).GetValue("CryptoJS.SHA3");
                //var aaat = encrypt.Invoke("0400Y40CB225019(3000KN)", 512);

                //var encrypt = new Engine().Execute(jsPath).GetValue("encrypt");
                //var aaat = encrypt.Invoke("0400Y40CB225019(3000KN)");

            }
            catch (Exception ex)
            { 
            
            }


            try
            {
                IJsEngine engineSwitcher = new JintJsEngine(new JintSettings()
                {

                    StrictMode = true

                });

                //IJsEngine engineSwitcher = new V8JsEngine();

                engineSwitcher.Execute(scripts);

                var result = engineSwitcher.CallFunction<string>("xp_sha3_512", $"0400Y40CB225019(3000KN)");

                var result2 = engineSwitcher.CallFunction<string>("xp_sha2_512", $"0401{name}");

            }
            catch (Exception ex)
            { 
            
            }




            //            #endregion


            //            var aaaa = @"0401广西交通研究院
            //";

            //           var da=  sha512Encode(aaaa);
            //            ///
            //            //af911a71da268319e08d285ecc2c54c50d25fa1a38dfab4b507d6b07477734f0d71a1e58dd4cfd5241117ff9e76ecef085136a05ecdf9fae4d197b4d4dbf36bf
            //            //0401广西交通研究院
            //            //广西交通研究院



            //            /*
            //            function sha3_512(str: string):string;
            //            begin
            //              result := Jsobj.Eval('CryptoJS.SHA3(''' + str + ''',512)');
            //            end;
            //            */

            //            //0400
            //            //9c1eee6eef2f15304073c1159a7c2ed59916bf5a66dc66271a93191a36ba6b32909d5b303d63b92366a36ccc47941c07d9a536015644e8f874e36d42fa37a1fe
            //            //9c1eee6eef2f15304073c1159a7c2ed59916bf5a66dc66271a93191a36ba6b32909d5b303d63b92366a36ccc47941c07d9a536015644e8f874e36d42fa37a1fe
            //            //ddf1ae4d992276f9f63402b12c46e260b700d2b6126be9ce53c10c48a7dffab38a79a64f4735b0941dcd804d9a46b7de090cd9bf662b264409aac8c913ab5f6e


            //            var txt = "0401";

            //            // var aaa2= Utils.Encrypt.Hash.HMACSHA512(txt,"512");
            //            //var aaa=  CyberCrypt._SHA.SHA384Hash(txt);
            //            // var des = SecurityHelper.SHA512Encrypt(txt);
            //            // var des2 = SHA512Encrypt(txt);
            //            // var des3 = sha512Encode(txt);

            //            //var a1 = SHA1Encrypt(txt);
            //            //var a2 = SHA256Encrypt(txt);
            //            //var a3 = SHA384Encrypt(txt);
            //            //var a4 = SHA512Encrypt(txt);

            //            System.Console.WriteLine("Hello World");


            #endregion

            // var txt = @"0401广西交通研究院
            // ";

            // txt = "0400Y40CB225019(3000KN)";


            // //9c1eee6eef2f15304073c1159a7c2ed59916bf5a66dc66271a93191a36ba6b32909d5b303d63b92366a36ccc47941c07d9a536015644e8f874e36d42fa37a1fe

            // var aa =   sha512Encode(txt);

            //var path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "sha.js");

            // string scripts = File.ReadAllText(path);
            // string func = string.Format(@"CryptoJS.SHA3('{0}',512)", txt);

            //var engine = new Engine();

            //engine.Execute(scripts);


            // path = @"D:\sha.js";

            // IJsEngine engine1 = new JintJsEngine( new JintSettings {  StrictMode = true });

            // engine1.ExecuteFile(path);

            //var adaa=  engine1.CallFunction("CryptoJS.SHA3",txt,512);


            // var engine = new Jurassic.ScriptEngine();
            // engine.ExecuteFile(scripts,Encoding.Unicode);

            //var aaa = engine.Evaluate(func);

            //  var res =  engine.Invoke("CryptoJS.SHA3", txt, 512);



            //var engine = new Engine();
            //var res = engine.Execute("1 + 2 + 3 + 4").GetCompletionValue();




            // var engine = new Engine();

            //var ns = engine.("./my-module.js");

            // var value = ns.Get("value").AsString();

            //Convert(txt);


            Console.ReadKey();
        }


        public static void Convert(string source)
        {
            //string path = AppDomain.CurrentDomain.BaseDirectory + @"Resources\scripts\mutate_dna.js";
            string path = @"C:\Users\Dell\Desktop\scripts\demo.js";

            path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "sha.js");

            string str2 = File.ReadAllText(path);
            string func = string.Format(@"CryptoJS.SHA3('{0}',512)", source);
            string result = ExecuteScript(func, str2);
            Console.WriteLine("result: " + result);
            //target = result;
        }

        private static string ExecuteScript(string sExpression, string sCode)
        {
            MSScriptControl.ScriptControl scriptControl = new MSScriptControl.ScriptControl();
            scriptControl.UseSafeSubset = true;
            scriptControl.Language = "JScript";
            scriptControl.AddCode(sCode);
            try
            {
                string str = scriptControl.Eval(sExpression).ToString();
                return str;
            }
            catch (Exception ex)
            {
                string str = ex.Message;
                return str;
            }
            //return null;
        }



        ////SHA为不可逆加密方式
        //public static string SHA1Encrypt(string Txt)
        //{
        //    var bytes = System.Text.Encoding.Default.GetBytes(Txt);
        //    var SHA = new System.Security.Cryptography.SHA1CryptoServiceProvider();
        //    var encryptbytes = SHA.ComputeHash(bytes);
        //    return Convert.ToBase64String(encryptbytes);
        //}
        //public static string SHA256Encrypt(string Txt)
        //{
        //    var bytes = System.Text.Encoding.Default.GetBytes(Txt);
        //    var SHA256 = new System.Security.Cryptography.SHA256CryptoServiceProvider();
        //    var encryptbytes = SHA256.ComputeHash(bytes);
        //    return Convert.ToBase64String(encryptbytes);
        //}
        //public static string SHA384Encrypt(string Txt)
        //{
        //    var bytes = System.Text.Encoding.Default.GetBytes(Txt);
        //    var SHA384 = new System.Security.Cryptography.SHA384CryptoServiceProvider();
        //    var encryptbytes = SHA384.ComputeHash(bytes);
        //    return Convert.ToBase64String(encryptbytes);
        //}
        //public static string SHA512Encrypt(string Txt)
        //{
        //    var bytes = System.Text.Encoding.Default.GetBytes(Txt);
        //    var SHA512 = new System.Security.Cryptography.SHA512CryptoServiceProvider();
        //    var encryptbytes = SHA512.ComputeHash(bytes);
        //    return Convert.ToBase64String(encryptbytes);
        //}

        public static string sha512Encode(string source)
        {
            string result = "";
            byte[] buffer = Encoding.UTF8.GetBytes(source);//UTF-8 编码

            //64字节,512位
            SHA512CryptoServiceProvider SHA512 = new SHA512CryptoServiceProvider();
            byte[] h5 = SHA512.ComputeHash(buffer);

            result = BitConverter.ToString(h5).Replace("-", string.Empty);

            return result.ToLower();
        }


        /// <summary>
        /// SHA512加密
        /// </summary>
        /// <param name="data">明文</param>
        /// <returns></returns>
        public static string SHA512Encrypt2(string originalData)
        {
                string result = string.Empty;
                byte[] bytValue = Encoding.UTF8.GetBytes(originalData);
                SHA512 sha512 = new SHA512CryptoServiceProvider();




                byte[] retVal = sha512.ComputeHash(bytValue);
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < retVal.Length; i++)
                {
                    sb.Append(retVal[i].ToString("x2"));
                }
                result = sb.ToString();
                return result;
        }
    }
}
